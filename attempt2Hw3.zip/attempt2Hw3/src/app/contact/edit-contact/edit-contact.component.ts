import { Component, OnInit, Input } from '@angular/core';
import { Contact } from '../../model/contactDesign';
import { ContactListService } from '../../contact-list.service';
import { ViewControlService } from '../../view-control.service';


@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css']
})
export class EditContactComponent implements OnInit {
  @Input() id: number = 0;
  contact: Contact = this.contactslist.contacts[this.id];
  firstName = "";
  lastName = "";
  email = "";
  company = "";
  phone = 0;
  

  constructor(private contactslist: ContactListService, private viewChange: ViewControlService) { }

  ngOnInit(): void {
    this.contact = this.contactslist.contacts[this.id];
    this.firstName = this.contact.firstName;
    this.lastName = this.contact.lastName;
    this.email = this.contact.email;
    this.company = this.contact.company;
    this.phone = this.contact.phone;
  }

  saveChanges(){
    var newContact: Contact = {
      firstName: this.contact.firstName,
      lastName: this.contact.lastName, 
      company: this.contact.company,
      phone: this.contact.phone,
      email: this.contact.email, 
    }

    this.contactslist.replaceContact(newContact, this.id);
    this.viewChange.setEditFalse();

  }
}
