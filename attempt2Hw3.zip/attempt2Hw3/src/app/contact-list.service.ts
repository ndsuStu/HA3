import { Injectable } from '@angular/core';
import { Contact } from "./model/contactDesign";

@Injectable({
  providedIn: 'root'
})
export class ContactListService {

  constructor() { }

  contacts: Contact[] = [
    { 
        firstName: "Evan",
        lastName: "Dramko",
        company: "NDSU",
        phone: 7010000004,
        email: "evan.dramko@ndsu.edu"
    } 
]

addContact(cntct: Contact){
    this.contacts.push(cntct);
    console.log("contact-list service, addContact");
}

removeContact(loc: number){
    this.contacts.splice(loc, 1);
    console.log("contact-list service, removeContact");


    // this.contacts.forEach((value, index) => {
    //     if(value === cntct){
    //         this.contacts.splice(index, 1);
    //     }
    // });
}

replaceContact(cntct: Contact, loc: number){
    this.contacts[loc] = cntct;
    console.log("contact-list service, replaceContact");

}

sortInitial(){
    this.mergeSort(this.contacts, 0, this.contacts.length-1);
}

mergeSort(arr: Array<Contact>, l: number, r:number){
    if(l >= r){ return; }
    let m = Math.floor(l + (r-l)/2);
    this.mergeSort(arr, l, m);
    this.mergeSort(arr, m+1, r);
    this.combine(arr, l, m, r);
}

combine(arr: Array<Contact>, l: number, m: number, r:number){
    let res = arr.slice(l, r+1);
    let i1 = l;
    let i2 = m+1;
    let i = l;

    while(i1 <= m && i2 <= r){
        const v1 = res[i1-l];
        const v2 = res[i2-l];
        if(v1.lastName < v2.lastName){
            arr[i++] = v1;
            ++i1;
        } else {
            arr[i++] = v2;
            ++i2;
        }
    }
    while(i1 <= m) { arr[i++] = res[i1++ -l];}
    while(i2 <= m) { arr[i++] = res[i2++ - l];}


}
}
