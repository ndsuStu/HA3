import { Component, OnInit, Output } from '@angular/core';
import { Contact } from '../model/contactDesign';
import { ContactListService } from '../contact-list.service';
import { ViewControlService } from '../view-control.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

  constructor(private contactslist: ContactListService, private viewChange: ViewControlService) { }

  ngOnInit(): void {
  }

  firstName: string = "";
  lastName: string = "";
  company: string = "";
  phone: number = 0;
  email: string = "";

  addContact(){
    var newContact: Contact = {
      firstName: this.firstName,
      lastName: this.lastName, 
      company: this.company,
      phone: this.phone,
      email: this.email, 
    }

    this.contactslist.addContact(newContact);
    this.returnToAppView();
  }

  returnToAppView(){
    this.viewChange.setAddFalse();
  }



}
