import { Component } from '@angular/core';
import { Contact } from "./model/contactDesign";
import { ContactListService } from "./contact-list.service";
import { ViewControlService } from './view-control.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ContactListService, ViewControlService]
})
export class AppComponent {
  constructor(private contactslist: ContactListService, private viewChange: ViewControlService){}

    //this is in the contact-list.service.ts file
    sort(){
      this.contactslist.sortInitial();
    }

  //============================================================
// addView: boolean = true;
// editView: boolean = true;

// setAddViewFalse(){
//   this.addView = !this.addView;
// }


  //============================================================
  //create copies of the view-controlling variables
  addViewApp: boolean = false;
  editViewApp: boolean = false;
  contacts: Array<Contact> = [];
  

  ngOnInit(): void {
    this.addViewApp = this.viewChange.addView;
    this.editViewApp = this.viewChange.editView;
    this.contacts = this.contactslist.contacts;
  }

//this is in the view-control.service.ts file
  setAddViewTrue(){
    this.viewChange.setAddTrue();
    this.viewChange.addViewUpdated.subscribe((addView: boolean) => (this.addViewApp = addView));
  }

}
