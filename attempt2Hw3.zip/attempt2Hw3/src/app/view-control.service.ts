import { Injectable, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ViewControlService {

  constructor() { }


//==================================================================

  addView: boolean = false;
  addViewUpdated = new EventEmitter<boolean>();

  setAddTrue(){
    this.addView = false;
    console.log("view-control service, setAddTrue");
    this.addViewUpdated.emit(this.addView);
  }

  setAddFalse(){
    this.addView = true;
    console.log("view-control service, setAddFalse");
    this.addViewUpdated.emit(this.addView);
  }

//==================================================================

  editView: boolean = false;
  editViewUpdated = new EventEmitter<boolean>();


  setEditTrue(){
    this.editView = true;
    console.log("view-control service, setEditTrue");
    this.editViewUpdated.emit(this.editView);


  }

  setEditFalse(){
    this.editView = false;
    console.log("view-control service, setEditFalse");
    this.editViewUpdated.emit(this.editView);


  }


}
